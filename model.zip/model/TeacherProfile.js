import mongoose from 'mongoose';

const teacherProfileSchema = new mongoose.Schema({
    fullName: { type: String, required: true },
    mobile: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    profilePhoto: { type: String }, 
    pincode: { type: String },
    city: { type: String },
    state: { type: String },
    address: { type: String },
    dob: { type: Date },
    gender: { type: String }
}, { timestamps: true });

const TeacherProfile = mongoose.model('TeacherProfile', teacherProfileSchema);
export default TeacherProfile;